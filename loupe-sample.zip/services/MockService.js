import loupe from "./LoupeService"

export default function Log(){
  loupe.information("MockService", "MockService Sample Log")
}